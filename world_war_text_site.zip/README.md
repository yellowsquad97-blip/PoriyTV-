# World War Text Simulator
سایت تک‌فایلی آماده GitHub Pages است.
فایل `index.html` را در ریپازیتوری قرار دهید و GitHub Pages را فعال کنید.
